/** Scenario data for Warlords of the Three Kingdoms. Stats are original characterizations. */

const SAVE_KEY = "warlords-tk-v1";

const ITEMS = {
  greenDragon: { id: "greenDragon", name: "Green Dragon Blade", war: 7 },
  serpentSpear: { id: "serpentSpear", name: "Serpent Spear", war: 5 },
  redHare: { id: "redHare", name: "Red Hare", war: 8, lea: 4 },
  featherFan: { id: "featherFan", name: "Crane-Feather Fan", int: 6 },
};

const FACTIONS = {
  liubei: { name: "Liu Bei", color: "#2f6d48", tag: "Hard", blurb: "Four oath-brothers in a poor town. Donghai is soft. The lords around it are not." },
  caocao: { name: "Cao Cao", color: "#1d4578", tag: "Even", blurb: "Yan province, a full council, and enemies on every road." },
  sunce: { name: "Sun Ce", color: "#8e2c2c", tag: "Even", blurb: "The Little Conqueror holds the lower Yangtze, with room to run south and west." },
  yuanshao: { name: "Yuan Shao", color: "#a07c32", tag: "Open", blurb: "The richest name in the north, and a proud court that does not always listen." },
  lvbu: { name: "Lü Bu", color: "#6d3d8c", tag: "Hard", blurb: "The finest fighter alive, seated on a restless city." },
  liubiao: { name: "Liu Biao", color: "#1f6f6a", tag: "Sheltered", blurb: "Jing is fat with grain. A recluse at Longzhong will not come out for just anyone." },
  liuzhang: { name: "Liu Zhang", color: "#6d5340", tag: "Sheltered", blurb: "The Shu roads are a wall. The court behind them is soft." },
  mateng: { name: "Ma Teng", color: "#b25a22", tag: "Even", blurb: "Liang horses and a hard western gate. The center is a long ride away." },
  gongsunzan: { name: "Gongsun Zan", color: "#8a8d90", tag: "Even", blurb: "White Horse riders in You province. Yuan Shao is the neighbor he hates." },
  yuanshu: { name: "Yuan Shu", color: "#8a6230", tag: "Hard", blurb: "A pretender's treasury and a thin claim. The south does not love him." },
  zhanglu: { name: "Zhang Lu", color: "#3c4e90", tag: "Sheltered", blurb: "Hanzhong's passes and a devout people. A small realm, difficult to crack." },
  lijue: { name: "Li Jue", color: "#6e2430", tag: "Hard", blurb: "Chang'an and ruined Luoyang. The court is a hostage, and the people know it." },
  kongrong: { name: "Kong Rong", color: "#2d7ea6", tag: "Hard", blurb: "A scholar of Beihai with one great captain and very little else." },
  zangba: { name: "Zang Ba", color: "#5c6b32", tag: "Hard", blurb: "A local captain in Donghai. Survive the first year and you have already done the surprising thing." },
};

const HEIRS = {
  liubei: "guanyu",
  caocao: "xiahoudun",
  sunce: "sunquan",
  yuanshao: "yanliang",
  lvbu: "zhangliao",
  liubiao: "huangzhong",
  liuzhang: "zhangren",
  mateng: "machao",
  gongsunzan: "tiankai",
  yuanshu: "jiling",
  zhanglu: "yanpu",
  lijue: "jiaxu",
  kongrong: "taishici",
  zangba: "changxi",
};

/** Road pairs. Neighbors are derived so the map cannot disagree with itself. */
const EDGES = [
  ["beiping", "ye"],
  ["beiping", "beihai"],
  ["ye", "jinyang"],
  ["ye", "puyang"],
  ["ye", "beihai"],
  ["jinyang", "luoyang"],
  ["jinyang", "changan"],
  ["changan", "tianshui"],
  ["changan", "luoyang"],
  ["changan", "hanzhong"],
  ["tianshui", "hanzhong"],
  ["hanzhong", "chengdu"],
  ["hanzhong", "jiangling"],
  ["luoyang", "chenliu"],
  ["chenliu", "puyang"],
  ["chenliu", "xiaopei"],
  ["chenliu", "shouchun"],
  ["puyang", "xiaopei"],
  ["puyang", "beihai"],
  ["beihai", "donghai"],
  ["donghai", "xiapi"],
  ["donghai", "xiaopei"],
  ["xiaopei", "xiapi"],
  ["xiaopei", "shouchun"],
  ["xiapi", "shouchun"],
  ["xiapi", "jianye"],
  ["shouchun", "xiangyang"],
  ["shouchun", "jianye"],
  ["xiangyang", "jiangling"],
  ["xiangyang", "jianye"],
  ["jiangling", "jianye"],
  ["jiangling", "wu"],
  ["jianye", "wu"],
];

const O = (p) => p;

const OFFICERS = [
  O({ id: "liubei", name: "Liu Bei", courtesy: "Xuande", lea: 74, war: 71, int: 74, chr: 98, loyalty: 100, faction: "liubei", art: "liu-bei.jpg", bio: "A late Han kinsman of thin means who binds people to him by keeping faith." }),
  O({ id: "guanyu", name: "Guan Yu", courtesy: "Yunchang", lea: 93, war: 97, int: 74, chr: 88, loyalty: 100, faction: "liubei", art: "guan-yu.jpg", gear: ["greenDragon"], bio: "Immensely tall, ruddy as a dark jujube, with a beard that spills down his chest. He carries the Green Dragon Blade." }),
  O({ id: "zhangfei", name: "Zhang Fei", courtesy: "Yide", lea: 86, war: 96, int: 34, chr: 46, loyalty: 100, faction: "liubei", art: "zhang-fei.jpg", gear: ["serpentSpear"], bio: "A butcher of fierce round eyes and a bristling beard, fastest to anger and first into a breach." }),
  O({ id: "zhaoyun", name: "Zhao Yun", courtesy: "Zilong", lea: 90, war: 94, int: 76, chr: 86, loyalty: 97, faction: "liubei", art: "zhao-yun.jpg", bio: "A young captain out of Changshan, calm in the crush, who rides with Liu Bei." }),
  O({ id: "caocao", name: "Cao Cao", courtesy: "Mengde", lea: 94, war: 72, int: 92, chr: 93, loyalty: 100, faction: "caocao", art: "cao-cao.jpg", bio: "A poet, a judge of men, and a warlord who treats grain and talent as weapons." }),
  O({ id: "xiahoudun", name: "Xiahou Dun", courtesy: "Yuanrang", lea: 86, war: 90, int: 56, chr: 76, loyalty: 96, faction: "caocao", art: "xiahou-dun.jpg", bio: "Cao Cao's cousin. He lost an eye in the wars and stayed in the front rank." }),
  O({ id: "xiahouyuan", name: "Xiahou Yuan", courtesy: "Miaocai", lea: 84, war: 86, int: 58, chr: 66, loyalty: 90, faction: "caocao", bio: "A rushing general, better at a flank march than at a council table." }),
  O({ id: "xunyu", name: "Xun Yu", courtesy: "Wenruo", lea: 46, war: 20, int: 96, chr: 90, loyalty: 94, faction: "caocao", art: "xun-yu.jpg", bio: "The first counselor of Cao Cao's court: precise, formal, and hard to surprise." }),
  O({ id: "guojia", name: "Guo Jia", courtesy: "Fengxiao", lea: 38, war: 16, int: 97, chr: 80, loyalty: 90, faction: "caocao", art: "guo-jia.jpg", bio: "A frail young strategist whose advice is usually finished before the room sits down." }),
  O({ id: "dianwei", name: "Dian Wei", courtesy: "", lea: 72, war: 94, int: 28, chr: 52, loyalty: 96, faction: "caocao", art: "dian-wei.jpg", bio: "Cao Cao's huge bodyguard, who fights with a pair of short halberds." }),
  O({ id: "xuchu", name: "Xu Chu", courtesy: "Zhongkang", lea: 74, war: 93, int: 30, chr: 58, loyalty: 92, faction: "caocao", art: "xu-chu.jpg", bio: "Called the Tiger Fool. Enormous, plain-spoken, and very hard to move." }),
  O({ id: "sunce", name: "Sun Ce", courtesy: "Bofu", lea: 92, war: 88, int: 72, chr: 90, loyalty: 100, faction: "sunce", art: "sun-ce.jpg", bio: "The Little Conqueror. He took the lower Yangtze while still young, and men followed the speed of it." }),
  O({ id: "sunquan", name: "Sun Quan", courtesy: "Zhongmou", lea: 70, war: 62, int: 80, chr: 84, loyalty: 94, faction: "sunce", art: "sun-quan.jpg", bio: "Sun Ce's younger brother. The novel seats him early among the heroes; history made him wait." }),
  O({ id: "zhouyu", name: "Zhou Yu", courtesy: "Gongjin", lea: 95, war: 71, int: 95, chr: 92, loyalty: 96, faction: "sunce", art: "zhou-yu.jpg", bio: "Handsome, a judge of music, and the strategist Sun Ce trusts with a flank." }),
  O({ id: "chengpu", name: "Cheng Pu", courtesy: "Demou", lea: 80, war: 78, int: 62, chr: 74, loyalty: 90, faction: "sunce", bio: "An old hand of the Sun family, steady where younger men are bright." }),
  O({ id: "handang", name: "Han Dang", courtesy: "Yigong", lea: 74, war: 76, int: 54, chr: 68, loyalty: 86, faction: "sunce", bio: "A river fighter who has served the Suns since the first campaigns." }),
  O({ id: "huanggai", name: "Huang Gai", courtesy: "Gongfu", lea: 82, war: 80, int: 68, chr: 76, loyalty: 92, faction: "sunce", art: "huang-gai.jpg", bio: "A stocky veteran of the south, loyal enough to stake his own body on a plan." }),
  O({ id: "lvbu", name: "Lü Bu", courtesy: "Fengxian", lea: 88, war: 100, int: 26, chr: 42, loyalty: 100, faction: "lvbu", art: "lv-bu.jpg", gear: ["redHare"], bio: "The finest duelist of the age, in a pheasant-tail headdress, riding the horse called Red Hare. He does not keep lords, or friends." }),
  O({ id: "chengong", name: "Chen Gong", courtesy: "Gongtai", lea: 42, war: 22, int: 90, chr: 68, loyalty: 70, faction: "lvbu", art: "chen-gong.jpg", bio: "A strategist who chose Lü Bu and spends his nights wondering why." }),
  O({ id: "zhangliao", name: "Zhang Liao", courtesy: "Wenyuan", lea: 91, war: 90, int: 76, chr: 80, loyalty: 54, faction: "lvbu", art: "zhang-liao.jpg", bio: "A calm killer from the north. His loyalty to Lü Bu is a habit, not a vow." }),
  O({ id: "gaoshun", name: "Gao Shun", courtesy: "", lea: 84, war: 82, int: 60, chr: 64, loyalty: 82, faction: "lvbu", bio: "Commander of a camp that does not break formation for a bribe." }),
  O({ id: "yuanshao", name: "Yuan Shao", courtesy: "Benchu", lea: 68, war: 45, int: 52, chr: 82, loyalty: 100, faction: "yuanshao", art: "yuan-shao.jpg", bio: "Four generations of highest office. He has the name, the grain, and a habit of ignoring his best advice." }),
  O({ id: "tianfeng", name: "Tian Feng", courtesy: "Yuanhao", lea: 36, war: 18, int: 88, chr: 66, loyalty: 58, faction: "yuanshao", bio: "A harsh counselor. Yuan Shao prefers to hear him after the mistake." }),
  O({ id: "yanliang", name: "Yan Liang", courtesy: "", lea: 78, war: 90, int: 40, chr: 52, loyalty: 74, faction: "yuanshao", bio: "Yuan Shao's famous vanguard. Brave, and not famous for caution." }),
  O({ id: "wenchou", name: "Wen Chou", courtesy: "", lea: 76, war: 87, int: 38, chr: 48, loyalty: 72, faction: "yuanshao", bio: "The other half of Yuan Shao's vanguard, a hammer looking for a wall." }),
  O({ id: "gaogan", name: "Gao Gan", courtesy: "Yuancai", lea: 55, war: 48, int: 46, chr: 42, loyalty: 62, faction: "yuanshao", bio: "Yuan Shao's nephew, set over Bing province to keep it in the family." }),
  O({ id: "guoyuan", name: "Guo Yuan", courtesy: "", lea: 50, war: 56, int: 48, chr: 44, loyalty: 55, faction: "yuanshao", bio: "A staff general of Jinyang, more useful on a payroll than in a song." }),
  O({ id: "yuanshu", name: "Yuan Shu", courtesy: "Gonglu", lea: 40, war: 32, int: 38, chr: 46, loyalty: 100, faction: "yuanshu", art: "yuan-shu.jpg", bio: "Yuan Shao's cousin, richer in silk than in judgment, already practicing an emperor's tone." }),
  O({ id: "jiling", name: "Ji Ling", courtesy: "", lea: 68, war: 76, int: 40, chr: 46, loyalty: 56, faction: "yuanshu", bio: "Yuan Shu's fighting general, sent wherever the pretender points." }),
  O({ id: "zhangxun", name: "Zhang Xun", courtesy: "", lea: 60, war: 64, int: 42, chr: 44, loyalty: 50, faction: "yuanshu", bio: "A mid-rank officer of Shouchun." }),
  O({ id: "liubiao", name: "Liu Biao", courtesy: "Jingsheng", lea: 55, war: 34, int: 72, chr: 76, loyalty: 100, faction: "liubiao", art: "liu-biao.jpg", bio: "Governor of Jing, a patron of scholars, slow to leave the safety of Xiangyang." }),
  O({ id: "huangzhong", name: "Huang Zhong", courtesy: "Hansheng", lea: 82, war: 92, int: 60, chr: 74, loyalty: 80, faction: "liubiao", art: "huang-zhong.jpg", bio: "An old bowman of Changsha who still draws a war bow. Age has not taken the arm." }),
  O({ id: "kuailiang", name: "Kuai Liang", courtesy: "Zirou", lea: 30, war: 14, int: 86, chr: 70, loyalty: 78, faction: "liubiao", bio: "A counselor of the Kuai clan. He would rather fortify a river than cross one." }),
  O({ id: "caimao", name: "Cai Mao", courtesy: "Degui", lea: 58, war: 62, int: 48, chr: 36, loyalty: 52, faction: "liubiao", bio: "Admiral of the Jing fleets, proud of the family that married into Liu Biao's house." }),
  O({ id: "wenping", name: "Wen Ping", courtesy: "Zhongye", lea: 78, war: 80, int: 64, chr: 70, loyalty: 74, faction: "liubiao", bio: "A general of Jiangling who keeps his head when the court does not." }),
  O({ id: "liuzhang", name: "Liu Zhang", courtesy: "Jiyu", lea: 40, war: 28, int: 48, chr: 64, loyalty: 100, faction: "liuzhang", art: "liu-zhang.jpg", bio: "Governor of Yi. The basin is easy to love and hard to invade, which suits his temper." }),
  O({ id: "zhangren", name: "Zhang Ren", courtesy: "", lea: 80, war: 86, int: 55, chr: 68, loyalty: 86, faction: "liuzhang", bio: "A loyal general of Shu who will not sell the passes twice." }),
  O({ id: "huangquan", name: "Huang Quan", courtesy: "Gongheng", lea: 62, war: 48, int: 78, chr: 66, loyalty: 72, faction: "liuzhang", bio: "An administrator of Yi who understands both maps and grain." }),
  O({ id: "mateng", name: "Ma Teng", courtesy: "Shoucheng", lea: 78, war: 80, int: 50, chr: 70, loyalty: 100, faction: "mateng", art: "ma-teng.jpg", bio: "A Liang warlord of the western road, father of Ma Chao, richer in horses than in cities." }),
  O({ id: "machao", name: "Ma Chao", courtesy: "Mengqi", lea: 90, war: 96, int: 44, chr: 80, loyalty: 88, faction: "mateng", art: "ma-chao.jpg", bio: "Called Splendid. A young Liang rider with a spear and a temper that travels." }),
  O({ id: "madai", name: "Ma Dai", courtesy: "", lea: 74, war: 82, int: 56, chr: 66, loyalty: 86, faction: "mateng", bio: "Ma Chao's cousin, a reliable arm of the western cavalry." }),
  O({ id: "gongsunzan", name: "Gongsun Zan", courtesy: "Bogui", lea: 82, war: 84, int: 48, chr: 68, loyalty: 100, faction: "gongsunzan", art: "gongsun-zan.jpg", bio: "Lord of Beiping, who fights under a white horsehair tassel and does not forgive Yuan Shao." }),
  O({ id: "tiankai", name: "Tian Kai", courtesy: "", lea: 64, war: 70, int: 44, chr: 50, loyalty: 72, faction: "gongsunzan", bio: "A captain of the white horse companies." }),
  O({ id: "zhanglu", name: "Zhang Lu", courtesy: "Gongqi", lea: 60, war: 46, int: 70, chr: 76, loyalty: 100, faction: "zhanglu", art: "zhang-lu.jpg", bio: "Master of the Five Pecks of Rice in Hanzhong. His passes are steep and his people are faithful." }),
  O({ id: "yanpu", name: "Yan Pu", courtesy: "", lea: 44, war: 38, int: 62, chr: 60, loyalty: 76, faction: "zhanglu", bio: "An elder of Zhang Lu's religious court." }),
  O({ id: "lijue", name: "Li Jue", courtesy: "", lea: 55, war: 62, int: 32, chr: 28, loyalty: 100, faction: "lijue", bio: "A remnant of Dong Zhuo's crew. He holds Chang'an and calls it the court." }),
  O({ id: "guosi", name: "Guo Si", courtesy: "", lea: 52, war: 60, int: 34, chr: 26, loyalty: 48, faction: "lijue", bio: "Li Jue's partner in the seizure of the emperor. They trust each other as far as the next granary." }),
  O({ id: "jiaxu", name: "Jia Xu", courtesy: "Wenhe", lea: 48, war: 18, int: 94, chr: 55, loyalty: 40, faction: "lijue", art: "jia-xu.jpg", bio: "A cold strategist serving the Chang'an junta because the road away has not yet looked better." }),
  O({ id: "yangfeng", name: "Yang Feng", courtesy: "", lea: 58, war: 66, int: 40, chr: 42, loyalty: 42, faction: "lijue", bio: "A White Wave captain dragged into the fight for Luoyang." }),
  O({ id: "kongrong", name: "Kong Rong", courtesy: "Wenju", lea: 38, war: 22, int: 80, chr: 82, loyalty: 100, faction: "kongrong", art: "kong-rong.jpg", bio: "A descendant of Confucius and governor of Beihai. His memorials are sharper than his garrisons." }),
  O({ id: "taishici", name: "Taishi Ci", courtesy: "Ziyi", lea: 84, war: 92, int: 62, chr: 80, loyalty: 84, faction: "kongrong", art: "taishi-ci.jpg", bio: "A towering archer who came to Kong Rong's rescue and has not yet decided where his service ends." }),
  O({ id: "zangba", name: "Zang Ba", courtesy: "Xuangao", lea: 70, war: 72, int: 55, chr: 60, loyalty: 100, faction: "zangba", bio: "A local power of Xu who gathered exiles and holds Donghai by familiarity more than by walls." }),
  O({ id: "changxi", name: "Chang Xi", courtesy: "", lea: 55, war: 64, int: 38, chr: 46, loyalty: 64, faction: "zangba", bio: "A brigand-captain allied to Zang Ba." }),
  O({ id: "zhugeliang", name: "Zhuge Liang", courtesy: "Kongming", lea: 92, war: 28, int: 100, chr: 90, loyalty: 70, faction: null, status: "hidden", homeCity: "xiangyang", difficulty: 90, visitsNeeded: 3, pride: 88, art: "zhuge-liang.jpg", gear: ["featherFan"], bio: "The Sleeping Dragon of Longzhong. In the histories he was still young in 194; the novel already has him waiting with a fan and a map." }),
  O({ id: "pangtong", name: "Pang Tong", courtesy: "Shiyuan", lea: 86, war: 26, int: 97, chr: 58, loyalty: 60, faction: null, status: "hidden", homeCity: "xiangyang", difficulty: 82, visitsNeeded: 1, pride: 70, art: "pang-tong.jpg", bio: "Called the Fledgling Phoenix. Homely, brilliant, and easier to overlook than Zhuge Liang." }),
  O({ id: "xushu", name: "Xu Shu", courtesy: "Yuanzhi", lea: 68, war: 66, int: 90, chr: 74, loyalty: 65, faction: null, status: "hidden", homeCity: "xiangyang", difficulty: 78, visitsNeeded: 2, pride: 74, bio: "A wandering scholar of Yingchuan who will recommend a greater mind than his own." }),
  O({ id: "fazheng", name: "Fa Zheng", courtesy: "Xiaozhi", lea: 55, war: 24, int: 93, chr: 52, loyalty: 50, faction: null, status: "hidden", homeCity: "chengdu", difficulty: 80, visitsNeeded: 1, pride: 66, bio: "A talent of Yi whom Liu Zhang's court has not learned how to use." }),
  O({ id: "ganning", name: "Gan Ning", courtesy: "Xingba", lea: 88, war: 91, int: 68, chr: 64, loyalty: 55, faction: null, status: "hidden", homeCity: "jiangling", difficulty: 72, visitsNeeded: 1, pride: 60, art: "gan-ning.jpg", bio: "A former river pirate who wears bells at his belt. He is still on Huang Zu's side of the Yangtze, and bored." }),
];

const CITIES = [
  { id: "beiping", name: "Beiping", province: "You", x: 631.9, y: 101.5, faction: "gongsunzan", governor: "gongsunzan", officers: ["gongsunzan", "tiankai"], gold: 900, rice: 9000, land: 42, flood: 32, trade: 30, people: 54, walls: 46, soldiers: 5200, training: 68 },
  { id: "ye", name: "Ye", province: "Ji", x: 540.7, y: 298.1, faction: "yuanshao", governor: "yuanshao", officers: ["yuanshao", "tianfeng", "yanliang", "wenchou"], gold: 2600, rice: 22000, land: 72, flood: 50, trade: 68, people: 62, walls: 58, soldiers: 7800, training: 56 },
  { id: "jinyang", name: "Jinyang", province: "Bing", x: 457.5, y: 220.3, faction: "yuanshao", governor: "gaogan", officers: ["gaogan", "guoyuan"], gold: 700, rice: 8000, land: 46, flood: 34, trade: 28, people: 48, walls: 40, soldiers: 2800, training: 46 },
  { id: "tianshui", name: "Tianshui", province: "Liang", x: 156.6, y: 389.9, faction: "mateng", governor: "mateng", officers: ["mateng", "machao", "madai"], gold: 650, rice: 7500, land: 36, flood: 28, trade: 22, people: 58, walls: 34, soldiers: 4200, training: 66 },
  { id: "changan", name: "Chang'an", province: "Yong", x: 299.9, y: 402.8, faction: "lijue", governor: "lijue", officers: ["lijue", "jiaxu"], gold: 800, rice: 7000, land: 32, flood: 24, trade: 30, people: 28, walls: 60, soldiers: 4600, training: 44 },
  { id: "luoyang", name: "Luoyang", province: "Sili", x: 456.6, y: 383.4, faction: "lijue", governor: "guosi", officers: ["guosi", "yangfeng"], gold: 400, rice: 3500, land: 22, flood: 18, trade: 16, people: 22, walls: 28, soldiers: 2400, training: 36 },
  { id: "hanzhong", name: "Hanzhong", province: "Yi", x: 214.5, y: 471.4, faction: "zhanglu", governor: "zhanglu", officers: ["zhanglu", "yanpu"], gold: 750, rice: 9000, land: 44, flood: 42, trade: 24, people: 80, walls: 55, soldiers: 3000, training: 52 },
  { id: "chengdu", name: "Chengdu", province: "Yi", x: 82.8, y: 601, faction: "liuzhang", governor: "liuzhang", officers: ["liuzhang", "zhangren", "huangquan"], gold: 1500, rice: 18000, land: 64, flood: 52, trade: 42, people: 74, walls: 50, soldiers: 3200, training: 36 },
  { id: "puyang", name: "Puyang", province: "Yan", x: 571, y: 326.2, faction: "caocao", governor: "xiahouyuan", officers: ["xiahouyuan", "dianwei", "xuchu"], gold: 900, rice: 9000, land: 52, flood: 42, trade: 44, people: 56, walls: 42, soldiers: 4200, training: 66 },
  { id: "chenliu", name: "Chenliu", province: "Yan", x: 546.5, y: 383.4, faction: "caocao", governor: "caocao", officers: ["caocao", "xunyu", "guojia", "xiahoudun"], gold: 1800, rice: 15000, land: 64, flood: 56, trade: 60, people: 68, walls: 52, soldiers: 6200, training: 72 },
  { id: "beihai", name: "Beihai", province: "Qing", x: 754.8, y: 271.1, faction: "kongrong", governor: "kongrong", officers: ["kongrong", "taishici"], gold: 600, rice: 6000, land: 40, flood: 36, trade: 34, people: 60, walls: 30, soldiers: 2200, training: 48 },
  { id: "donghai", name: "Donghai", province: "Xu", x: 757.4, y: 376.9, faction: "zangba", governor: "zangba", officers: ["zangba", "changxi"], gold: 280, rice: 3200, land: 30, flood: 24, trade: 20, people: 48, walls: 16, soldiers: 1400, training: 38 },
  { id: "xiaopei", name: "Xiaopei", province: "Xu", x: 655.5, y: 381.8, faction: "liubei", governor: "liubei", officers: ["liubei", "guanyu", "zhangfei", "zhaoyun"], gold: 720, rice: 9000, land: 40, flood: 34, trade: 28, people: 76, walls: 30, soldiers: 3000, training: 70 },
  { id: "xiapi", name: "Xiapi", province: "Xu", x: 701.4, y: 402.8, faction: "lvbu", governor: "lvbu", officers: ["lvbu", "chengong", "zhangliao", "gaoshun"], gold: 780, rice: 6500, land: 40, flood: 30, trade: 34, people: 42, walls: 48, soldiers: 5600, training: 70 },
  { id: "shouchun", name: "Shouchun", province: "Yang", x: 648.9, y: 499.5, faction: "yuanshu", governor: "yuanshu", officers: ["yuanshu", "jiling", "zhangxun"], gold: 1300, rice: 10000, land: 50, flood: 36, trade: 48, people: 40, walls: 42, soldiers: 3600, training: 42 },
  { id: "xiangyang", name: "Xiangyang", province: "Jing", x: 442.4, y: 528.1, faction: "liubiao", governor: "liubiao", officers: ["liubiao", "kuailiang", "huangzhong"], gold: 1700, rice: 16000, land: 66, flood: 60, trade: 52, people: 72, walls: 60, soldiers: 4000, training: 50 },
  { id: "jiangling", name: "Jiangling", province: "Jing", x: 444.1, y: 619.4, faction: "liubiao", governor: "caimao", officers: ["caimao", "wenping"], gold: 900, rice: 11000, land: 56, flood: 54, trade: 46, people: 66, walls: 44, soldiers: 2800, training: 48 },
  { id: "jianye", name: "Jianye", province: "Yang", x: 737.9, y: 527, faction: "sunce", governor: "sunce", officers: ["sunce", "zhouyu", "huanggai"], gold: 1100, rice: 10000, land: 50, flood: 52, trade: 56, people: 62, walls: 38, soldiers: 4800, training: 70 },
  { id: "wu", name: "Wu", province: "Yang", x: 819.7, y: 567, faction: "sunce", governor: "chengpu", officers: ["chengpu", "sunquan", "handang"], gold: 700, rice: 8000, land: 46, flood: 50, trade: 40, people: 64, walls: 32, soldiers: 2600, training: 58 },
];

const VISIT_LINES = {
  zhugeliang: [
    "The boy at the gate says Master Zhuge is walking the ridge. Tea is offered. Nothing else.",
    "Zhuge Liang speaks of rain, mulberry, and the price of salt. He will not speak of banners.",
    "He is home. He unrolls a map of the realm and agrees to leave the furrow.",
  ],
  xushu: [
    "Xu Shu listens, then says a single visit is how beggars ask.",
    "He saddles a horse. On the road he will talk of a greater mind at Longzhong.",
  ],
};

const DUEL_LINES = {
  "guanyu|lvbu": "The crescent blade and the halberd lock. Even the horses seem to wait.",
  "zhangfei|lvbu": "Zhang Fei roars, and Lü Bu answers with the halberd rather than words.",
  "zhaoyun|machao": "Two spears turn the dust between them into a bright wheel.",
  "guanyu|yanliang": "Yan Liang comes out to take a head. The beard and the blade are already there.",
  "huangzhong|xiahoudun": "An old bowman and a one-eyed veteran measure each other and dislike the math.",
};

const MONTHS = [
  ["Spring", "1st month"],
  ["Spring", "2nd month"],
  ["Spring", "3rd month"],
  ["Summer", "4th month"],
  ["Summer", "5th month"],
  ["Summer", "6th month"],
  ["Autumn", "7th month"],
  ["Autumn", "8th month"],
  ["Autumn", "9th month"],
  ["Winter", "10th month"],
  ["Winter", "11th month"],
  ["Winter", "12th month"],
];

const FEATURED = ["liubei", "caocao", "sunce", "yuanshao", "lvbu", "liubiao", "mateng", "gongsunzan"];

/** Standing work a city repeats until an order changes it. */
const JOBS = {
  fields: { id: "fields", label: "Fields", cost: 40, hint: "Opens farmland. Autumn grain depends on it, and on the governor." },
  dikes: { id: "dikes", label: "Dikes", cost: 50, hint: "Raises flood control. Summer is cruel to a low dike." },
  markets: { id: "markets", label: "Markets", cost: 55, hint: "Raises commerce. A clever governor draws more gold from the same market." },
  drill: { id: "drill", label: "Drill", cost: 25, hint: "Raises training. Leadership decides how fast the camp learns." },
  patrol: { id: "patrol", label: "Patrol", cost: 30, hint: "Raises public order. Charm keeps the wards quiet." },
  walls: { id: "walls", label: "Walls", cost: 80, hint: "Raises the defense that soaks a charge." },
  levy: { id: "levy", label: "Levy", cost: 40, hint: "Enlists troops and lowers training. Order limits how many will come." },
};

/** Mountain roads. Armies arrive tired. */
const PASS_ROADS = new Set(["changan|hanzhong", "hanzhong|tianshui", "chengdu|hanzhong"]);

/** River crossings. The same fatigue as a pass. */
const RIVER_ROADS = new Set(["jiangling|jianye", "jiangling|wu", "xiangyang|jianye", "xiapi|jianye", "shouchun|jianye"]);

/** Peach Garden, and Cao Cao with Xiahou Dun. */
const OATHS = [
  ["liubei", "guanyu", "zhangfei"],
  ["caocao", "xiahoudun"],
];

const RIVAL_PAIRS = [["yuanshao", "gongsunzan"]];

/** Chen Gong serves Lü Bu and does not trust him. */
const DOUBTS = [["chengong", "lvbu"]];

/** Loyalty is a habit, not a vow. */
const THIN_LOYALTY = ["zhangliao"];

const AIMS = {
  liubei: { title: "Restore the Han", text: "Escort the emperor out of Chang'an and keep him in a city you hold." },
  caocao: { title: "Hold the court", text: "Take the emperor and keep him in a city you rule." },
  sunce: { title: "Secure the river", text: "Hold Jianye, Wu, and Jiangling." },
  yuanshao: { title: "Master the north", text: "Hold Ye, Jinyang, and Beiping." },
  lvbu: { title: "The strongest arm", text: "Win a duel against a ruling lord." },
  liubiao: { title: "Keep Jing", text: "Hold Xiangyang and Jiangling." },
  liuzhang: { title: "Shut the basin", text: "Hold Chengdu and Hanzhong." },
  mateng: { title: "The western gate", text: "Hold Tianshui and Chang'an." },
  gongsunzan: { title: "Break Yuan Shao", text: "Take Ye." },
  yuanshu: { title: "A title of his own", text: "Hold Shouchun and Jianye." },
  zhanglu: { title: "The passes", text: "Hold Hanzhong and Chengdu." },
  lijue: { title: "Keep the hostage", text: "Hold Chang'an while the emperor is still there." },
  kongrong: { title: "A scholar's coast", text: "Hold Beihai and one city besides." },
  zangba: { title: "Outlast the year", text: "Still hold Donghai when the year turns." },
};
